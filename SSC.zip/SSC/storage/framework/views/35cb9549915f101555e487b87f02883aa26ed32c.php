

<?php $__env->startSection('wrapper'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add a New User Profile</h1>
    </div>

    <div class="card shadow mb-4">
        <form class="user card-body">
            <div class="form-group row">
                <div class="col-sm-3 mb-3 mb-sm-0">
                    <input type="text" class="form-control form-control-user" id="exampleFirstName" 
                        placeholder="First Name">
                </div>
                <div class="col-sm-3">
                    <input type="text" class="form-control form-control-user" id="exampleLastName" 
                        placeholder="Last Name">
                </div>
            </div>
            <div class="form-group">
                <input type="email" class="form-control form-control-user col-sm-4" id="exampleInputEmail" 
                    placeholder="Email Address">
            </div>
            <div class="form-group row">
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <input type="password" class="form-control form-control-user" 
                        id="exampleInputPassword" placeholder="Password">
                </div>
                <div class="col-sm-4">
                    <input type="password" class="form-control form-control-user" 
                        id="exampleRepeatPassword" placeholder="Repeat Password">
                </div>
            </div>
            <div class="form-group">
                <input type="date" class="form-control form-control-user col-sm-2" id="exampleInputEmail" 
                    placeholder="">
            </div>
            <hr>
            <a href="user_table.html" class="btn btn-primary btn-user col-sm-3">
                Submit
            </a>
            <a href="<?php echo e(URL("/admin-panel/user-management")); ?>" class="btn btn-primary btn-user col-sm-3">
                Cancel
            </a>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin-Panel.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SSC\resources\views/Admin-panel/user-add.blade.php ENDPATH**/ ?>