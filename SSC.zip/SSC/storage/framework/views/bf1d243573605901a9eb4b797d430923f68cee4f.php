

<?php $__env->startSection('wrapper'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin-Panel.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SSC\resources\views/Admin-panel/dashboard.blade.php ENDPATH**/ ?>