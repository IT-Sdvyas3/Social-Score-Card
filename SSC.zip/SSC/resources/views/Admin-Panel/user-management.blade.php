@extends('Admin-Panel.main-layout')

@section('wrapper')
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-primary d-inline-block">User Management</h5>
            <a href="{{ URL("/admin-panel/add-user") }}" class="btn btn-sm btn-primary float-right">Add</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-bordered " id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email Address</th>
                            <th>Password</th>
                            <th>DOB</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email Address</th>
                            <th>Password</th>
                            <th>DOB</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>

                        <tr class="clickable" onclick="window.location='Profile_view.html'"> 
                            <td>System Architect</td>
                            <td>Edinburgh</td>
                            <td>61</td>
                            <td>2011/04/25</td>
                            <td>System Architect</td>
                            
                            <td class="text-center">
                                <a class="btn btn-warning py-0" href="profile_edit.html" >Edit</a>
                                <a class="btn btn-danger py-0">Delete</a>
                            </td>
                        
                        </tr>
                
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection